ESX             = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('dfa-grandmas:payBill')
AddEventHandler('dfa-grandmas:payBill', function()
    local src = source
	local xPlayer = ESX.GetPlayerFromId(src)
	--change price here for revive
	xPlayer.removeMoney(450)
    exports['mythic_notify']:DoHudText('error', 'you were charged 450$')
end)